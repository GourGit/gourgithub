import logging
from flask import render_template, request, redirect, url_for, flash, session, jsonify
from app import app, db
from models import Registration, Admin
from werkzeug.security import check_password_hash
from flask_login import login_user, logout_user, login_required, current_user

# Event categories and their respective events
EVENT_CATEGORIES = {
    "eSports": ["BGMI", "Valorant", "EFootball"],
    "Coding": ["Coding Contest", "Coding Treasure Hunt"],
    "Engineering": ["Robotics", "Circuitronics"],
    "Fun": ["Tug of War"]
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/events')
def events():
    return render_template('events.html', event_categories=EVENT_CATEGORIES)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            # Extract form data
            full_name = request.form.get('full_name')
            email = request.form.get('email')
            phone = request.form.get('phone')
            college = request.form.get('college')
            event_category = request.form.get('event_category')
            event_name = request.form.get('event_name')
            team_name = request.form.get('team_name', '')
            team_members = request.form.get('team_members', '')
            
            # Validate required fields
            if not all([full_name, email, phone, college, event_category, event_name]):
                flash('All required fields must be filled out!', 'danger')
                return redirect(url_for('register'))
            
            # Create registration
            registration = Registration(
                full_name=full_name,
                email=email,
                phone=phone,
                college=college,
                event_category=event_category,
                event_name=event_name,
                team_name=team_name,
                team_members=team_members
            )
            
            db.session.add(registration)
            db.session.commit()
            
            flash('Registration successful! We look forward to seeing you at Signifia.', 'success')
            return redirect(url_for('register'))
        except Exception as e:
            app.logger.error(f"Registration error: {e}")
            flash('An error occurred during registration. Please try again.', 'danger')
            return redirect(url_for('register'))
    
    return render_template('register.html', event_categories=EVENT_CATEGORIES)

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if current_user.is_authenticated:
        return redirect(url_for('admin_dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        admin = Admin.query.filter_by(username=username).first()
        
        if admin and check_password_hash(admin.password_hash, password):
            login_user(admin)
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('admin_login.html')

@app.route('/admin/logout')
@login_required
def admin_logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('admin_login'))

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    registrations = Registration.query.all()
    return render_template('admin_dashboard.html', registrations=registrations, event_categories=EVENT_CATEGORIES)

@app.route('/api/get_events', methods=['POST'])
def get_events():
    category = request.form.get('category')
    if category in EVENT_CATEGORIES:
        return jsonify({"events": EVENT_CATEGORIES[category]})
    return jsonify({"events": []})

@app.route('/api/registrations')
@login_required
def api_registrations():
    category = request.args.get('category')
    event = request.args.get('event')
    
    query = Registration.query
    
    if category:
        query = query.filter_by(event_category=category)
    
    if event:
        query = query.filter_by(event_name=event)
    
    registrations = query.all()
    return jsonify({
        "registrations": [reg.to_dict() for reg in registrations]
    })
