from app import db
from flask_login import UserMixin
from datetime import datetime

class Admin(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)

class Registration(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    college = db.Column(db.String(100), nullable=False)
    event_category = db.Column(db.String(50), nullable=False)
    event_name = db.Column(db.String(50), nullable=False)
    team_name = db.Column(db.String(100), nullable=True)
    team_members = db.Column(db.Text, nullable=True)
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Registration {self.full_name} for {self.event_name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'full_name': self.full_name,
            'email': self.email,
            'phone': self.phone,
            'college': self.college,
            'event_category': self.event_category,
            'event_name': self.event_name,
            'team_name': self.team_name,
            'team_members': self.team_members,
            'registration_date': self.registration_date.strftime('%Y-%m-%d %H:%M:%S')
        }
