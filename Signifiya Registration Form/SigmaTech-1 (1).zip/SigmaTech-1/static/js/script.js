document.addEventListener('DOMContentLoaded', function() {
    // Event category selection handler
    const categorySelect = document.getElementById('event_category');
    const eventSelect = document.getElementById('event_name');

    if (categorySelect && eventSelect) {
        categorySelect.addEventListener('change', function() {
            fetch('/api/get_events', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ category: this.value })
            })
            .then(response => response.json())
            .then(data => {
                eventSelect.innerHTML = '<option value="">Select Event</option>';
                data.events.forEach(event => {
                    const option = document.createElement('option');
                    option.value = event;
                    option.textContent = event;
                    eventSelect.appendChild(option);
                });
            });
        });
    }

    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // Live status display
    const countdownTimer = document.getElementById('countdown-timer');
    if (countdownTimer) {
        countdownTimer.innerHTML = '<div class="live-status"><h2 class="glow-text">Signifia is Live!</h2></div>';
    }

    // Admin dashboard filters
    const adminCategoryFilter = document.getElementById('admin-category-filter');
    const adminEventFilter = document.getElementById('admin-event-filter');

    if (adminCategoryFilter && adminEventFilter) {
        adminCategoryFilter.addEventListener('change', function() {
            const category = this.value;
            if (category) {
                fetchEventsForAdmin(category);
                filterRegistrations();
            } else {
                clearAdminEventFilter();
                filterRegistrations();
            }
        });

        adminEventFilter.addEventListener('change', function() {
            filterRegistrations();
        });
    }

    // Initialize AOS animation library
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: false
    });


    // Handle form validation (This part is already included above from edited code)


    // Add responsive navigation behavior
    initNavigation();
});

// Countdown timer for event (This part is already included above from edited code)


// Fetch events for a selected category (This function is not used in the edited code but should be retained for completeness)
function fetchEvents(category) {
    const eventNameSelect = document.getElementById('event_name');
    if (!eventNameSelect) return;

    // Clear current options
    clearEventSelect();

    // Add loading indicator
    eventNameSelect.innerHTML = '<option value="">Loading events...</option>';

    // Send AJAX request to get events for the selected category
    const formData = new FormData();
    formData.append('category', category);

    fetch('/api/get_events', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        clearEventSelect();

        if (data.events && data.events.length > 0) {
            data.events.forEach(event => {
                const option = document.createElement('option');
                option.value = event;
                option.textContent = event;
                eventNameSelect.appendChild(option);
            });
        } else {
            eventNameSelect.innerHTML = '<option value="">No events available</option>';
        }

        // Trigger change event to handle team fields visibility
        const event = new Event('change');
        eventNameSelect.dispatchEvent(event);
    })
    .catch(error => {
        console.error('Error fetching events:', error);
        eventNameSelect.innerHTML = '<option value="">Error loading events</option>';
    });
}

// Clear event select dropdown
function clearEventSelect() {
    const eventNameSelect = document.getElementById('event_name');
    if (eventNameSelect) {
        eventNameSelect.innerHTML = '<option value="">Select an event</option>';
    }
}

// Toggle team fields based on selected event
function toggleTeamFields(eventName) {
    const teamFieldsDiv = document.getElementById('team_fields');
    if (!teamFieldsDiv) return;

    // Team-based events
    const teamEvents = ['BGMI', 'Valorant', 'Tug of War', 'Robotics'];

    if (teamEvents.includes(eventName)) {
        teamFieldsDiv.classList.remove('d-none');
    } else {
        teamFieldsDiv.classList.add('d-none');
    }
}

// Fetch events for admin dashboard filters
function fetchEventsForAdmin(category) {
    const adminEventFilter = document.getElementById('admin-event-filter');
    if (!adminEventFilter) return;

    // Clear current options
    adminEventFilter.innerHTML = '<option value="">All Events</option>';

    // Send AJAX request to get events for the selected category
    const formData = new FormData();
    formData.append('category', category);

    fetch('/api/get_events', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.events && data.events.length > 0) {
            data.events.forEach(event => {
                const option = document.createElement('option');
                option.value = event;
                option.textContent = event;
                adminEventFilter.appendChild(option);
            });
        }
    })
    .catch(error => {
        console.error('Error fetching events for admin:', error);
    });
}

// Clear admin event filter
function clearAdminEventFilter() {
    const adminEventFilter = document.getElementById('admin-event-filter');
    if (adminEventFilter) {
        adminEventFilter.innerHTML = '<option value="">All Events</option>';
    }
}

// Filter registrations in admin dashboard
function filterRegistrations() {
    const categoryFilter = document.getElementById('admin-category-filter').value;
    const eventFilter = document.getElementById('admin-event-filter').value;

    fetch(`/api/registrations?category=${categoryFilter}&event=${eventFilter}`)
        .then(response => response.json())
        .then(data => {
            const registrationsTable = document.getElementById('registrations-table');
            const tbody = registrationsTable.querySelector('tbody');

            // Clear current rows
            tbody.innerHTML = '';

            if (data.registrations && data.registrations.length > 0) {
                data.registrations.forEach((reg, index) => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${index + 1}</td>
                        <td>${reg.full_name}</td>
                        <td>${reg.email}</td>
                        <td>${reg.phone}</td>
                        <td>${reg.college}</td>
                        <td>${reg.event_category}</td>
                        <td>${reg.event_name}</td>
                        <td>${reg.team_name || '-'}</td>
                        <td>${reg.team_members || '-'}</td>
                        <td>${reg.registration_date}</td>
                    `;
                    tbody.appendChild(row);
                });

                // Update registration count
                document.getElementById('registration-count').textContent = data.registrations.length;
            } else {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td colspan="10" class="text-center">No registrations found</td>
                `;
                tbody.appendChild(row);
                document.getElementById('registration-count').textContent = '0';
            }
        })
        .catch(error => {
            console.error('Error fetching filtered registrations:', error);
        });
}

// Form validation (This part is already included above from edited code)

// Responsive navigation
function initNavigation() {
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');

    if (navbarToggler && navbarCollapse) {
        // Close the menu when a nav-link is clicked on mobile
        const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 992) {
                    navbarCollapse.classList.remove('show');
                }
            });
        });
    }
}