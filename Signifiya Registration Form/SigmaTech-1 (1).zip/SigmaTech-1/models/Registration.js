
const mongoose = require('mongoose');

const RegistrationSchema = new mongoose.Schema({
  fullName: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  phone: {
    type: String,
    required: true
  },
  college: {
    type: String,
    required: true
  },
  eventCategory: {
    type: String,
    required: true
  },
  eventName: {
    type: String,
    required: true
  },
  teamName: String,
  teamMembers: String,
  registrationDate: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Registration', RegistrationSchema);
