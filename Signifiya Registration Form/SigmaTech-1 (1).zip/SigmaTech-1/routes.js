
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const Admin = require('./models/Admin');
const Registration = require('./models/Registration');

const EVENT_CATEGORIES = {
  "eSports": ["BGMI", "Valorant", "EFootball"],
  "Coding": ["Coding Contest", "Coding Treasure Hunt"],
  "Engineering": ["Robotics", "Circuitronics"],
  "Fun": ["Tug of War"]
};

// Auth middleware
const isAuthenticated = (req, res, next) => {
  if (req.session.adminId) {
    next();
  } else {
    res.redirect('/admin/login');
  }
};

router.get('/', (req, res) => {
  res.render('index');
});

router.get('/events', (req, res) => {
  res.render('events', { event_categories: EVENT_CATEGORIES });
});

router.get('/register', (req, res) => {
  res.render('register', { event_categories: EVENT_CATEGORIES });
});

router.post('/register', async (req, res) => {
  try {
    const registration = new Registration({
      fullName: req.body.full_name,
      email: req.body.email,
      phone: req.body.phone,
      college: req.body.college,
      eventCategory: req.body.event_category,
      eventName: req.body.event_name,
      teamName: req.body.team_name,
      teamMembers: req.body.team_members
    });
    await registration.save();
    res.redirect('/register?success=true');
  } catch (err) {
    res.redirect('/register?error=true');
  }
});

router.get('/contact', (req, res) => {
  res.render('contact');
});

router.get('/admin/login', (req, res) => {
  res.render('admin_login');
});

router.post('/admin/login', async (req, res) => {
  try {
    const admin = await Admin.findOne({ username: req.body.username });
    if (admin && await bcrypt.compare(req.body.password, admin.password)) {
      req.session.adminId = admin._id;
      res.redirect('/admin/dashboard');
    } else {
      res.redirect('/admin/login?error=true');
    }
  } catch (err) {
    res.redirect('/admin/login?error=true');
  }
});

router.get('/admin/dashboard', isAuthenticated, async (req, res) => {
  const registrations = await Registration.find();
  res.render('admin_dashboard', { registrations, event_categories: EVENT_CATEGORIES });
});

router.get('/admin/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/admin/login');
});

router.post('/api/get_events', (req, res) => {
  const category = req.body.category;
  res.json({ events: EVENT_CATEGORIES[category] || [] });
});

module.exports = router;
